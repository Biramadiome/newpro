﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GestionBancaire.entites;

namespace GestionBancaire.many
{
    internal interface IAgence
    {
        void AjouterAgence(Agence agence);
        void AfficherAgences();
        void SupprimerAgence(int delid);
        void ModifierAgence(int numAg);
    }
}
