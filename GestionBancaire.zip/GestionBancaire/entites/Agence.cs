﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionBancaire.entites
{
    internal class Agence
    {
        private int id;
        private int code;
        private string libelle;
        public static int nbagence;

       

        public int Id { get { return id; } set { id = value; } }
        public int Code { get { return code; } set { code = value; } }
        public string Libelle { get { return libelle; } set { libelle = value; } }
        
        public Agence()
        {
            nbagence++;
            Id = nbagence;
        }

        public Agence(int code, string libelle)
        {
            
            Code = code;
            Libelle = libelle;
        }

        public override string ToString()
        {
            return "id :"+id+" code :"+code+"libelle :"+libelle;
        }
    }
}
