﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionBancaire.entites
{
    internal class CompteSimple : Compte
    {
        //attribut
        private int tauxcouvert;
        //getter setter
        public int Tauxcouvert { get { return tauxcouvert; } set { tauxcouvert = value; } }


        //constructeur
        public CompteSimple(int solde, int numcompte, int tauxcouvert) : base(solde, numcompte)
        {
            Tauxcouvert = tauxcouvert;
        }
        public CompteSimple()
        {
            nbcompte++;
            Id = nbcompte;
        }

        public override string ToString()
        {
            return base.ToString()+" taux couvert : "+ tauxcouvert;
        }
    }
}
