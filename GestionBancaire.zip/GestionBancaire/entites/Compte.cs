﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionBancaire.entites
{
    internal class  Compte
    {  
        //attribut
        protected int  id;
        protected int numcompte;
        protected int solde;
        protected static int nbcompte;
        //getter setter,
        public int Id { get { return id; } set { id = value; } }
            
        public int Numcompte { get { return numcompte; } set { numcompte = value; } }
        public int Solde {  get { return solde; } set { solde = value; } }
        //constructeur
        public Compte()
        {

        }
        public Compte(int solde,int numcompte)
        {
            Solde = solde;
            Numcompte = numcompte;
        }
        //affichage
        public override string ToString()
        {
            return "id :"+id+" solde :"+solde+" numcompte :"+numcompte;
        }
        


    }
}
