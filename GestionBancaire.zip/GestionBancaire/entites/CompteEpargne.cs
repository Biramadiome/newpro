﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestionBancaire.entites
{
    internal class CompteEpargne : Compte
    {
        //attribut
        private int duree;
        //getter setter
        public int Duree { get { return duree; } set { duree = value; } }
        //constructeur
        public CompteEpargne()
        {
            nbcompte++;
            Id = nbcompte;
        }

        public CompteEpargne(int solde, int numcompte, int duree) : base( solde, numcompte)
        {
            Duree = duree;
            
        }
        //affichage
        public override string ToString()
        {
            return base.ToString()+" duree : "+duree;
        }
        





    }
}
